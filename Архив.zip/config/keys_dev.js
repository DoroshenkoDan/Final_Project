module.exports = {
  mongoURI:
    'Сюда копируем URI для доступа в БД, например: mongodb+srv://username:password@..........................',
  secretOrKey: 'random very very secret string',
};

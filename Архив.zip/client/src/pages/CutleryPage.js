import React from 'react'
export default function CutleryPage() {
  return <></>
}

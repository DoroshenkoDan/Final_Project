import React from 'react'
export default function CatalogPage() {
  return <></>
}

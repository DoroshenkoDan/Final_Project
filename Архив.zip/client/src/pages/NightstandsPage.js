import React from 'react'

export default function NightstandsPage() {
  return <></>
}

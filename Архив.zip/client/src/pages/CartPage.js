import React from 'react'
export default function CartPage() {
    return <></>
}

import React from 'react'
import ProductsContainer from '../components/ProductsContainer'
export default function HomePage() {
    return (
        <>
            <p>Хелоу</p>
            <ProductsContainer />
        </>
    )
}

import React from 'react'

export default function PlantPotsPage() {
  return <></>
}
